package poly.petshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsignmentPy00168ApplicationTests {

	@Test
	void contextLoads() {
	}

}
