# Hướng dẫn triển khai Crypto Trading Bot

## Yêu cầu hệ thống
- Python 3.9+
- pip (Python package installer)
- Linux hoặc macOS (Windows cũng hỗ trợ nhưng khuyến nghị Linux/macOS)

## Bước 1: Cài đặt các gói phụ thuộc
```bash
pip install -r requirements.txt
```

## Bước 2: Cấu hình
1. Sao chép file `.env.example` thành `.env`
   ```bash
   cp .env.example .env
   ```
2. Chỉnh sửa file `.env` và cung cấp các thông tin API key cần thiết:
   - BINANCE_API_KEY: API key Binance của bạn
   - BINANCE_API_SECRET: API secret Binance của bạn
   - TELEGRAM_BOT_TOKEN: Token của Telegram bot (nếu muốn nhận thông báo)
   - TELEGRAM_CHAT_ID: Chat ID Telegram của bạn
3. Kiểm tra file `account_config.json` để cấu hình tài khoản và chiến lược

## Bước 3: Cấp quyền thực thi cho các script
```bash
chmod +x *.sh
```

## Bước 4: Khởi động bot
```bash
./watchdog_runner.sh
```

Lệnh này sẽ khởi động toàn bộ hệ thống bao gồm:
- Web server cho giao diện người dùng
- Các script giám sát và tự động khôi phục
- Thông báo qua Telegram khi có sự cố

## Bước 5: Truy cập giao diện quản lý
Mở trình duyệt và truy cập: http://localhost:5000

## Xử lý sự cố
Nếu gặp vấn đề, vui lòng tham khảo file `recovery_kit.md` để biết cách khắc phục.

## Cách dừng bot
```bash
pkill -f "watchdog_runner.sh"
pkill -f "python"
pkill -f "gunicorn"
```
