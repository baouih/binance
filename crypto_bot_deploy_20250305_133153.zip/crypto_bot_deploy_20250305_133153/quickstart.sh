#!/bin/bash
# Script khởi động nhanh

# Kiểm tra Python và pip
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 không được cài đặt. Vui lòng cài đặt Python 3.9+"
    exit 1
fi

# Đảm bảo các thư mục cần thiết tồn tại
mkdir -p logs data

# Cài đặt các thư viện cần thiết
pip install -r requirements.txt

# Kiểm tra file .env
if [ ! -f .env ]; then
    echo "CẢNH BÁO: File .env không tồn tại."
    echo "Đang tạo từ mẫu. Vui lòng chỉnh sửa với thông tin thực tế của bạn."
    cp .env.example .env
fi

# Cấp quyền thực thi cho các script
chmod +x *.sh *.py

# Khởi động bot
echo "Khởi động bot..."
./watchdog_runner.sh

echo "Bot đã được khởi động!"
echo "Truy cập http://localhost:5000 để xem giao diện quản lý"
