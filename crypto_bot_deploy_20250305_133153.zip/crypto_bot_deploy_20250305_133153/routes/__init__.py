"""
Package routes - Chứa các blueprint routes cho ứng dụng
"""